package com.example.demo_03.service;


import com.example.demo_03.model.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;
import java.util.stream.Collectors;

@Service
public class PretestService {


    //1st problem
    public ResponseEntity<Object> getOrderDetails(OrderDetailsReq req) throws InterruptedException, ExecutionException {

        //intializing the thread pool size
        ExecutorService executorService = Executors.newFixedThreadPool(5);
        List<Callable<Object>> callable = new ArrayList<>();
        List<Future<Object>> resultList ;

        try {
            //adding the methods using callable
            callable.add(() -> getOrders(req.getOrderId()));
            callable.add(() -> getShipment(req.getOrderId()));

            //invoking both the methods uasing invokeAll method
            resultList = executorService.invokeAll(callable);

            //getting respective details from the order and shipment details
            Order order = (Order) resultList.get(0).get();
            Shipment shipment = (Shipment) resultList.get(1).get();

            //returning the combined response
            return ResponseEntity.ok(new OrderDetailsResponse(order, shipment));
        } catch (Exception e) {
            throw e;
        } finally {
            //finally closing the executor service
            executorService.shutdown();
        }
    }

    public Order getOrders(String orderId) {
        //method for returning the order details
        List<Order> orderList = Arrays.asList(new Order ("Order1", "Prod1", 2.0));
        Order order = orderList.stream().filter(i -> {
            if(i.getOrderId().equals(orderId)) {
                return true;
            }
            return false;
        }).findFirst().orElse(null);

        return order;

    }
    public Shipment getShipment(String orderId) throws ParseException {
        //method for returning shipment details
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
        List<Shipment> shipmentList = Arrays.asList(new Shipment ("Order1", "Ship1", "Prod1", df.parse("2021-02-19"), Double.valueOf(2.0)));
        Shipment shipment = shipmentList.stream().filter(i -> {
            if(i.getOrderId().equals(orderId)) {
                return true;
            }
            return false;
        }).findFirst().orElse(null);

        return shipment;
    }


    //2nd question
    public ResponseEntity<Object> getAvailability(AvailabilityReq req) {

        //Setting the data
        List<SupplyData> supplyDataList = Arrays.asList(new SupplyData("Product1",Double.valueOf(10)),
                new SupplyData("Product2",Double.valueOf(5)));

        List<DemandData> demandDataList = Arrays.asList(new DemandData("Product1",Double.valueOf(2)),
                new DemandData("Product2",Double.valueOf(5)));

        //As per product id storing the data
        List<SupplyData> supply = supplyDataList.stream().filter(i -> i.getProductId().equals(req.getProductId())).collect(Collectors.toList());
        List<DemandData> demand = demandDataList.stream().filter(i -> i.getProductId().equals(req.getProductId())).collect(Collectors.toList());

        //getting the supply quantity and demand quantity
        List<Double> supplyQuantity = supply.stream().map(i -> i.getQuantity()).collect(Collectors.toList());
        List<Double> demandQuantity = demand.stream().map(i -> i.getQuantity()).collect(Collectors.toList());

        //getting the availability;
        Double availQuantity = supplyQuantity.get(0) - demandQuantity.get(0);

        if(availQuantity > 0) {
            return ResponseEntity.ok(new AvailabilityRes(req.getProductId(), availQuantity));
        } else {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
    }



}
