package com.example.demo_03.controller;


import com.example.demo_03.model.AvailabilityReq;
import com.example.demo_03.model.OrderDetailsReq;
import com.example.demo_03.model.UpdateSupplyPayload;
import com.example.demo_03.service.PretestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import java.text.ParseException;
import java.util.concurrent.ExecutionException;

@RestController
public class PretestController {

    @Autowired
    PretestService pretestService;

    //1st question
    @PostMapping("/getOrderDetails")
    public ResponseEntity<Object> getOrderDetails(@RequestBody OrderDetailsReq req) throws ExecutionException, InterruptedException {

        return pretestService.getOrderDetails(req);
    }
    //2nd question
    @PostMapping("/getAvailability")
    public ResponseEntity<Object> getAvailability(@RequestBody AvailabilityReq req) {

        return pretestService.getAvailability(req);
    }


}
